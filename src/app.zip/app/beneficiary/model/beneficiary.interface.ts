import { BeneficiaryProfile } from './beneficiaryProfile.interface';
export class Beneficiary{
    beneficiaryProfile: BeneficiaryProfile;
}