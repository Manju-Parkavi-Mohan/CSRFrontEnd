export interface BeneficiaryProfile {
    benficiaryId: number;
    benficiaryName: string;
    benficiarySecretaryName: string;
    benficiaryAddress: string;
    benficiaryPhoneNumber: number;
    benficiaryCity: string;
    benficiaryState: string;
    panNumber: number;
    benficiaryStatus: string;
    fcraNumber: string;
    vetting: string;
}
